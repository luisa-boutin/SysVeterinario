﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SysVeterinario_V3.Model
{
    public class EspeciesModel
    {
        public Int32 IdEspecieAnimal { get; set; }

        public string NomeEspecieAnimal { get; set; }
    }
}
