﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SysVeterinario_V3.Model
{
    public class AnimaisPorClienteModel
    {
        public Int32 IdAnimal { get; set; }

        public Int32 IdCliente { get; set; }
    }
}
