﻿using System;
using SysVeterinario_V3.View;

namespace SysVeterinario_V3
{
    class Program
    {
        static void Main(string[] args)
        {
            MenuPrincipal vMenu = new MenuPrincipal();

            vMenu.AbrirMenu();
        }
    }
}
