﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SysVeterinario_V3.View
{
    public abstract class MenuAbstrato
    {
        public abstract void AbrirMenu();

    }
}
